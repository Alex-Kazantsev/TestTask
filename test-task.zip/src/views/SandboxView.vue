<template>
  <v-container>
    <SettingsForm class="mb-10" />
    <SandboxElements />
  </v-container>
</template>

<script lang="ts" setup>
import SettingsForm from '@/components/sandbox/SettingsForm.vue'
import SandboxElements from '@/components/sandbox/SandboxElements.vue'
</script>
