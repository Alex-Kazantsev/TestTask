export interface ISettingsFormData {
  width: null | string
  height: null | string
  borderRadius: null | string
  backgroundColor: null | string
}
