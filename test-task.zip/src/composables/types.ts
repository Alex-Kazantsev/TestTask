export function useStringToBoolean(value: string): boolean {
  return value === 'true'
}
