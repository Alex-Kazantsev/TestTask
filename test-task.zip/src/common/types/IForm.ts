export interface IForm<T> {
  valid: boolean
  data: T
}
